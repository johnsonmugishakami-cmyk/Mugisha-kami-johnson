/* Name: Mugisha kami johnson
   Student ID: 29622 */

#include <stddef.h>
#include <stdio.h>
size_t my_strlen(const char *s)
{
    const char *p = s;
    while (*p != '\0')
    {
        p++;
    }
    return p - s;
}
char my_to_lower(char c)
{
    if (c >= 'A' && c <= 'Z')
    {
        return c + ('a' - 'A');
    }
    return c;
}
int matches_at(const char *p, const char *needle)
{
    while (*needle != '\0')
    {
        if (*p != *needle)
        {
            return 0;
        }
        p++;
        needle++;
    }
    return 1;
}
int is_blank(char c)
{
    if (c == ' ' || c == '\t')
    {
        return 1;
    }
    return 0;
}
const char *str_find_char(const char *s, char c)
{
    while (1)
    {
        if (*s == c)
            return s;
        if (*s == '\0')
            return NULL;
        s++;
    }
}
void str_reverse(char *s)
{
    size_t len = my_strlen(s);
    if (len == 0)
    {
        return;
    }
    char *left = s;
    char *right = s + len - 1;
    while (left < right)
    {
        char tmp = *left;
        *left = *right;
        *right = tmp;
        left++;
        right--;
    }
}
int str_compare_ci(const char *a, const char *b)
{
    while (*a != '\0' && *b != '\0')
    {
        char x = my_to_lower(*a);
        char y = my_to_lower(*b);
        if (x < y)
        {
            return -1;
        }
        if (x > y)
        {
            return 1;
        }
        a++;
        b++;
    }
    if (*a == '\0' && *b == '\0')
    {
        return 0;
    }
    if (*a == '\0')
    {
        return -1;
    }
    return 1;
}
size_t str_copy_bounded(char *dst, const char *src, size_t size)
{
    size_t len = my_strlen(src);
    if (size == 0)
    {
        return len;
    }
    size_t i = 0;
    while (i < size - 1 && src[i] != '\0')
    {
        dst[i] = src[i];
        i++;
    }
    dst[i] = '\0';
    return len;
}
const char *str_find_sub(const char *hay, const char *needle)
{
    while (1)
    {
        if (matches_at(hay, needle))
        {
            return hay;
        }
        if (*hay == '\0')
        {
            return NULL;
        }
        hay++;
    }
}
size_t str_squeeze(char *s)
{
    char *read = s;
    char *write = s;
    while (is_blank(*read))
    {
        read++;
    }
    while (*read != '\0')
    {
        if (is_blank(*read))
        {
            while (is_blank(*read))
            {
                read++;
            }
            if (*read != '\0')
            {
                *write = ' ';
                write++;
            }
        }
        else
        {
            *write = *read;
            write++;
            read++;
        }
    }
    *write = '\0';
    return (size_t)(write - s);
}
int str_split(char *s, char delim, char *fields[], int max_fields)
{
    int count = 1;
    if (max_fields > 0)
    {
        fields[0] = s;
    }
    while (*s != '\0')
    {
        if (*s == delim)
        {
            *s = '\0';
            if (count < max_fields)
            {
                fields[count] = s + 1;
            }
            count++;
        }
        s++;
    }
    return count;
}
int main(void)
{
    const char *word = "hello";
    const char *pos = str_find_char(word, 'l');
    if (pos != NULL)
        printf("find_char: offset %d (expected 2)\n", (int)(pos - word));
    else
        printf("find_char: NULL (expected offset 2)\n");
    char rev[] = "hello";
    str_reverse(rev);
    printf("reverse: \"%s\" (expected \"olleh\")\n", rev);
    printf("compare_ci: %d (expected -1)\n", str_compare_ci("apple", "Banana"));
    char small[4] = "";
    size_t n = str_copy_bounded(small, "hello", sizeof small);
    printf("copy_bounded: returned %d, dst \"%s\" (expected 5, \"hel\")\n",
           (int)n, small);
    const char *hay = "aaab";
    const char *found = str_find_sub(hay, "aab");
    if (found != NULL)
        printf("find_sub: offset %d (expected 1)\n", (int)(found - hay));
    else
        printf("find_sub: NULL (expected offset 1)\n");
    char messy[] = "  hello   world  ";
    size_t len = str_squeeze(messy);
    printf("squeeze: returned %d, [%s] (expected 11, [hello world])\n",
           (int)len, messy);
    char line[] = "red,green,blue";
    char *fields[5];
    int count = str_split(line, ',', fields, 5);
    printf("split: returned %d (expected 3)\n", count);
    for (int i = 0; i < count && i < 5; i++)
        printf("  fields[%d] = [%s]\n", i, fields[i]);
    return 0;
}
